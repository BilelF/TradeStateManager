﻿using System.Collections.Generic;
using System.IO;
using ClassLibrary;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

           string currentpath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;
           var elements = Trade.ParseXMLItem(currentpath + @"\xmlSource\input.xml");

           List<TradeState> StateList =  Trade.GetState(elements);

           Trade.ExportToCSV(StateList, currentpath + @"\output\result.xml");
          
        }
    }
} 
