﻿namespace ClassLibrary
{
    public class TradeState
    {
        /// <summary>
        /// Enum of trade state
        /// </summary>
        public enum EnumState
        {
            Accepted,
            Pending,
            Rejected
        }
        /// <summary>
        /// get/set CorrelationID
        /// </summary>
        public string CorrelationID { get; set; }
        /// <summary>
        ///  get/set NumberOfTrades
        /// </summary>
        public int NumberOfTrades { get; set; }
        /// <summary>
        /// get/set State
        /// </summary>
        public EnumState State { get; set; }
    }
}
