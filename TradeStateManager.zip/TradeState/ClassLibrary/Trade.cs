﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace ClassLibrary
{
    public static class Trade
    {
        /// <summary>
        /// Parse XML File with XMLReader
        /// </summary>
        /// <param name="uri"></param>
        /// <returns>IEnumerable<XElement></returns>
        /// <author>Bilel FERCHICHI</author>
        public static IEnumerable<XElement> ParseXMLItem(string uri)
        {

            if (!File.Exists(uri))
            {
                throw new FileNotFoundException();
            }

              using (XmlReader reader = XmlReader.Create(uri))
            {
                XElement trade = null;
                reader.MoveToContent();
                // Parse the file, save header information when encountered, and yield the  
                // Item XElement objects as they are created.  

                // loop through Trade elements  
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.Name == "Trade")
                    {
                        trade = XElement.ReadFrom(reader) as XElement;
                        if (trade != null)
                        {

                            yield return trade;
                        }
                    }
                }
            }

        }

        /// <summary>
        /// Get trade state
        /// </summary>
        /// <param name="elements"></param>
        /// <returns>List<TradeState></returns>
        /// <author>Bilel FERCHICHI</author>        
        public static List<TradeState> GetState(IEnumerable<XElement> elements)
        {
            if (elements == null || elements.Count() == 0)
                return null;

            var groupedElements = elements.GroupBy(el => new
            {
                CorrelationID = el.Attribute("CorrelationId").Value,
                NumberOfTrades = el.Attribute("NumberOfTrades").Value,
                Limit = el.Attribute("Limit").Value
            }).Select(gr => new
            {
                gr.Key.CorrelationID,
                gr.Key.NumberOfTrades,
                gr.Key.Limit,
                Count = gr.Count(),
                Sum = gr.Sum(x => Int32.Parse(x.Value))
            }).ToList();


            List<TradeState> list = new List<TradeState>();
            //get pending trade state
            var pendingTrade = from el in groupedElements
                               where el.Count != Int32.Parse(el.NumberOfTrades)
                               select new TradeState { CorrelationID = el.CorrelationID, NumberOfTrades = Int32.Parse(el.NumberOfTrades), State = TradeState.EnumState.Pending };

            list.AddRange(pendingTrade.ToList<TradeState>());

            //get rejected trade state
            var rejectedTrade = from el in groupedElements
                                where el.Sum > Int32.Parse(el.Limit)
                                select new TradeState { CorrelationID = el.CorrelationID, NumberOfTrades = Int32.Parse(el.NumberOfTrades), State = TradeState.EnumState.Rejected };

            list.AddRange(rejectedTrade.ToList<TradeState>());

            //get accepted trade state
            var acceptedTrade = from el in groupedElements
                                where el.Count == Int32.Parse(el.NumberOfTrades)
                                 && el.Sum < Int32.Parse(el.Limit)
                                select new TradeState { CorrelationID = el.CorrelationID, NumberOfTrades = Int32.Parse(el.NumberOfTrades), State = TradeState.EnumState.Accepted };

            list.AddRange(acceptedTrade.ToList<TradeState>());

            return list;
        }

        /// <summary>
        /// Export TradeState List to CSV file
        /// </summary>
        /// <param name="StateList"></param>
        /// <author>Bilel FERCHICHI</author>
        public static void ExportToCSV(List<TradeState> StateList, string uri)
        {

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("CorrelationID,NumberOfTrades,State");
            foreach (var item in StateList)
            {
               sb.AppendLine(string.Format("{0},{1},{2}", item.CorrelationID, item.NumberOfTrades, item.State));
            }
            System.IO.File.WriteAllText(
                System.IO.Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, uri),
                sb.ToString());
        }
    }
}
