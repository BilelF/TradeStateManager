﻿using System.Collections.Generic;
using System.IO;
using Xunit;

namespace ClassLibrary.Tests
{
    public class TradeTests
    {
        [Fact]
        public void GetState_ListShouldReturn()
        {

            //Call methods to test
            string currentpath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;
            var elements = Trade.ParseXMLItem(currentpath + @"\xmlSource\input.xml");
            List<TradeState> Actual_StateList = Trade.GetState(elements);

            //Compare Actual_StateList with expected result
            Assert.Collection(
                Actual_StateList,
                item =>
                {
                    Assert.Equal("200", item.CorrelationID);
                    Assert.Equal(2, item.NumberOfTrades);
                    Assert.Equal(TradeState.EnumState.Pending, item.State);                    
                },
                item =>
                {
                    Assert.Equal("222", item.CorrelationID);
                    Assert.Equal(1, item.NumberOfTrades);
                    Assert.Equal(TradeState.EnumState.Rejected, item.State);
                },
                 item =>
                {
                    Assert.Equal("234", item.CorrelationID);
                    Assert.Equal(3, item.NumberOfTrades);
                    Assert.Equal(TradeState.EnumState.Accepted, item.State);
                });            
        }
        
    }
}
